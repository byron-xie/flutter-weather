import 'dart:collection';

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter/services.dart';
import 'dart:io';
import 'package:sqflite/src/sqflite_impl.dart';

class TodoProvider {
  Database db;

  Future<bool> open() async {
//    String path = await getDatabasesPath();
//    print("path:"+path);
    var databasesPath = await getDatabasesPath();
    String path = join(databasesPath, 'weather.db');
    File file = File(path);
    bool isExits = await file.exists();
    if (!isExits) {
      ByteData byteData = await rootBundle.load(join('assets', 'weather.db'));
      List<int> data = byteData.buffer
          .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes);
      await file.writeAsBytes(data);
    }
    db = await openDatabase(path);
    print("path:" + db.toString());
    print("path:" + "${db.isOpen}");
    return db.isOpen;
  }

  Future<String> getCityId(String cityName, String district) async {
    cityName = cityName.replaceAll('市', '');
    district = district.replaceAll('区', '');
    print("citys:  cityName" + cityName.toString());
    print("citys:  district" + district.toString());
    print("citys:  db ${db != null}");
    print("citys:  db.isOpen ${db.isOpen}");
    if (db != null && db.isOpen) {
      String key = "'" + '%' + cityName + '.' + district + '%' + "'";
      ListBase<Map<String, dynamic>> citys = await db
          .rawQuery('SELECT city_num,name FROM citys WHERE name like ' + key);
      QueryRow value = citys.first;
      print("citys: value" + value.toString());

      print("citys:  numbernumbernumbernumber" + "${value['city_num']}");
      citys.map((re) {
        print("citys:  raaaaaaaaaaaaaaaae" + re.toString());
      });
      print("citys:" + citys.toString());

      return value['city_num'];
    }
    return null;
  }
}
